package com.estadoprivado.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.estadoprivado.app.ui.screens.HomeScreen
import com.estadoprivado.app.ui.screens.MediaViewerScreen
import com.estadoprivado.app.ui.screens.SettingsScreen
import com.estadoprivado.app.ui.theme.EstadoPrivadoTheme
import com.estadoprivado.app.viewmodel.StatusViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: StatusViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkThemePref by viewModel.darkThemeState.collectAsState()
            val systemDark = isSystemInDarkTheme()
            val useDark = isDarkThemePref ?: systemDark

            EstadoPrivadoTheme(darkTheme = useDark) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    EstadoPrivadoApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun EstadoPrivadoApp(viewModel: StatusViewModel) {
    val navController = rememberNavController()

    // Selector SAF oficial con persistencia de permisos
    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.onFolderSelected(uri)
        }
    }

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                viewModel = viewModel,
                onSelectFolder = { folderPickerLauncher.launch(null) },
                onNavigateToSettings = { navController.navigate("settings") },
                onMediaClick = { index ->
                    navController.navigate("viewer/$index")
                }
            )
        }

        composable("viewer/{initialIndex}") { backStackEntry ->
            val indexStr = backStackEntry.arguments?.getString("initialIndex")
            val initialIndex = indexStr?.toIntOrNull() ?: 0

            MediaViewerScreen(
                viewModel = viewModel,
                initialIndex = initialIndex,
                onBack = { navController.popBackStack() }
            )
        }

        composable("settings") {
            SettingsScreen(
                viewModel = viewModel,
                onChangeFolder = { folderPickerLauncher.launch(null) },
                onBack = { navController.popBackStack() }
            )
        }
    }
}
