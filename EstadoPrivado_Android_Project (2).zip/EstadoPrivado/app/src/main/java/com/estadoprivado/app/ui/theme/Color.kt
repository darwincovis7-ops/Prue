package com.estadoprivado.app.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta Oficial Estado Privado: Verde Esmeralda y Azul Profundo
val EmeraldPrimary = Color(0xFF00DF81)
val EmeraldLight = Color(0xFF48DFBC)
val EmeraldDark = Color(0xFF00C896)

val NavyBackground = Color(0xFF081325)
val NavySurface = Color(0xFF0E2034)
val NavySurfaceElevated = Color(0xFF162A42)
val NavyDark = Color(0xFF050C17)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val AccentEmerald = Color(0xFF00DF81)

// Modo claro elegante
val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)
