package com.estadoprivado.app.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.estadoprivado.app.data.MediaItem
import com.estadoprivado.app.data.MediaType
import com.estadoprivado.app.data.StorageHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class TabFilter {
    RECENT,
    PHOTOS,
    VIDEOS
}

class StatusViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext

    private val _currentFolderUri = MutableStateFlow<Uri?>(null)
    val currentFolderUri: StateFlow<Uri?> = _currentFolderUri.asStateFlow()

    private val _allItems = MutableStateFlow<List<MediaItem>>(emptyList())
    val allItems: StateFlow<List<MediaItem>> = _allItems.asStateFlow()

    private val _selectedTab = MutableStateFlow(TabFilter.RECENT)
    val selectedTab: StateFlow<TabFilter> = _selectedTab.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _darkThemeState = MutableStateFlow<Boolean?>(null)
    val darkThemeState: StateFlow<Boolean?> = _darkThemeState.asStateFlow()

    val filteredItems: StateFlow<List<MediaItem>> = combine(_allItems, _selectedTab) { items, tab ->
        when (tab) {
            TabFilter.RECENT -> items
            TabFilter.PHOTOS -> items.filter { it.type == MediaType.IMAGE }
            TabFilter.VIDEOS -> items.filter { it.type == MediaType.VIDEO }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        _darkThemeState.value = StorageHelper.getThemePreference(context)
        val savedUri = StorageHelper.getSavedFolderUri(context)
        if (savedUri != null) {
            _currentFolderUri.value = savedUri
            refreshStatuses()
        }
    }

    fun onFolderSelected(uri: Uri) {
        StorageHelper.saveSelectedFolderUri(context, uri)
        _currentFolderUri.value = uri
        refreshStatuses()
    }

    fun setTab(tab: TabFilter) {
        _selectedTab.value = tab
    }

    fun setDarkTheme(isDark: Boolean?) {
        StorageHelper.saveThemePreference(context, isDark)
        _darkThemeState.value = isDark
    }

    fun refreshStatuses() {
        val uri = _currentFolderUri.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val list = StorageHelper.loadStatusesFromTree(context, uri)
                _allItems.value = list
                if (list.isEmpty()) {
                    _errorMessage.value = "No se encontraron estados en esta carpeta. Asegúrate de haber visto estados en WhatsApp antes o verifica la ruta."
                }
            } catch (e: Exception) {
                _errorMessage.value = "Error al leer la carpeta: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun clearFolder() {
        StorageHelper.clearSavedFolder(context)
        _currentFolderUri.value = null
        _allItems.value = emptyList()
    }
}
