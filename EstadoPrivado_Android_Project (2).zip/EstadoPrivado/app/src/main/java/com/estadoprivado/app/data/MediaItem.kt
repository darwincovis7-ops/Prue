package com.estadoprivado.app.data

import android.net.Uri

enum class MediaType {
    IMAGE,
    VIDEO
}

data class MediaItem(
    val uri: Uri,
    val name: String,
    val type: MediaType,
    val sizeBytes: Long,
    val lastModified: Long,
    val durationFormatted: String? = null
)
